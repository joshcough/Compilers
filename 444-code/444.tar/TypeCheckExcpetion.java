class TypeCheckException extends Exception{}
