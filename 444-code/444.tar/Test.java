class Test{

  static public void main( String args[] ){
    // Var var = new Local();
    //var.setName( "i" );
    //Cls type = new Cls("int");
    //var.setType( type );
    //System.out.println( var.toString() );
    //final String s = null;
    //String f = s + "i";
    //System.out.println(s);
    //final boolean b;
    //int x = 5 + i;
    //s = "5";
    //b = true;
    //b = false;
    //b = true;
    //this[9] = false;
    //int x = new int();
    //Test t = new Test();
    //t.ok();
    //boolean b = true == 1;
    //boolean b = 1 == 2 == 3;
  }
  
  void ok(){
    System.out.println("ok");
    Test t = this;
    t.main( null );
  }

}
